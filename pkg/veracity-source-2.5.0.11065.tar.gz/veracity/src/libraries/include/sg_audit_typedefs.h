/*
Copyright 2010-2013 SourceGear, LLC

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

/**
 *
 * @file sg_audit_typedefs.h
 *
 */

//////////////////////////////////////////////////////////////////

#ifndef H_SG_AUDIT_TYPEDEFS_H
#define H_SG_AUDIT_TYPEDEFS_H

BEGIN_EXTERN_C;

#define SG_AUDIT__WHEN__NOW  (-1)
#define SG_AUDIT__WHO__FROM_SETTINGS (NULL)

#define SG_AUDIT__USERID "userid"
#define SG_AUDIT__USERNAME "username"
#define SG_AUDIT__TIMESTAMP "timestamp"

typedef struct
{
    SG_int64 when_int64;
    char who_szUserId[SG_GID_BUFFER_LENGTH];
} SG_audit;

END_EXTERN_C;

#endif//H_SG_AUDIT_TYPEDEFS_H

