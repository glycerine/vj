The item will also be removed from the working copy. The remove will only be
allowed if there are no pending operations for the item.
