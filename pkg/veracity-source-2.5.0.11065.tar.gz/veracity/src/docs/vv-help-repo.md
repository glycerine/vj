When used without a subcommand and from within a working copy, 'vv repo'
prints information about the local repository associated with 
the working copy, such as the repository name and the default
push/pull location.

The command 'vv repos' is an alias for 'vv repo list'.
