If used from within a working copy and --repo is not specified, the
repository associated with the working copy will be used.

If no subcommand is specified, the current user account for the repository is displayed.

The command 'vv users' is an alias for 'vv user list'.
